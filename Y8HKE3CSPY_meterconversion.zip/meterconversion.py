a=float(input())
print("Convert " + str(int(a)) + "km into m : " + str(int(a*1000)) + "m")


print("Convert " + str(int(a)) + " kilobyte into bytes : " + str(int(a*1000)) + "bytes")


print("Convert " + str(int(a)) + " hectometer into decimeter : " + str(int(a*1000)) + "decimeters")